BEST FRIEND PASSWORD PAGE

1. GitHub mein sign in karein.
2. New repository banayein; naam rakhein: best-friend-treat
3. Repository ko Public rakhein.
4. Add file > Upload files par jaakar index.html upload karein aur Commit changes karein.
5. Settings > Pages kholein.
6. Build and deployment mein Deploy from a branch chunein.
7. Branch: main, folder: / (root) chunein; Save karein.
8. GitHub jo Pages URL dikhaye, use copy karke mujhe bhej dein.

Us URL se main QR code bana dunga.

Password: 1234

Note: Yeh simple password screen hai. Password page ke source code mein dekha ja sakta hai,
isliye yeh confidential/security-sensitive information ke liye secure protection nahi hai.
